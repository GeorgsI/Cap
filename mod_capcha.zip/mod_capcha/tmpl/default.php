<?php 
defined('_JEXEC') or die; 
// echo $hello; 

use Joomla\CMS\Factory;
$session = Factory::getSession();

//include_once('capcha.php');

/*

if($session->get('myVa') == null){


   
    // include'Controlls.php';
 
 
 
 
 
    exit();
}
 */

if(isset($_POST['capcha']) && $session->get('myVa') == $_POST['capcha'] ){
    echo $session->get('myVa');
    header('Location: http://joomlatest');
    
}
else{
    $session->clear();
    
   
}



?>

<?php echo $str ?>
<form  method='POST'>
<input type='text' name='capcha' placeholder='введите тест'>
<input type='submit' name='submit' value='Отправить'>
</form>